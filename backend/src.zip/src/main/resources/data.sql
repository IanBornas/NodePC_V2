INSERT INTO products (name, description, price, stock)
VALUES
('Intel Core i7', '12th Gen Processor', 350.00, 10),
('NVIDIA RTX 4070', 'High-performance graphics card', 599.99, 5),
('Samsung SSD 1TB', 'Fast storage drive', 120.00, 20),
('Corsair Vengeance 16GB', 'DDR4 RAM module', 80.00, 15);
